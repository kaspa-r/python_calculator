from setuptools import setup, find_packages

VERSION = '0.0.1'
DESCRIPTION = "A calculator package used for summation, subtraction, multiplication, division and taking a root out of a stored value"

# Setting up
setup(
    name="Calculator_karutka",
    version=VERSION,
    author="Kasparas Rutkauskas",
    author_email="kasparas.r7@gmail.com",
    description=DESCRIPTION,
    packages=find_packages(),
    # install_requires=['mpi4py>=2.0'],
    classifiers=[
        'Intended Audience :: Learning',
        'License :: OSI Approved :: MIT License',  
        "Programming Language :: Python :: 3",
        "Operating System :: Unix",
        "Operating System :: MacOS :: MacOS X",
        "Operating System :: Microsoft :: Windows",
    ]
)

from setuptools import setup, find_packages

setup(
        name="contacts",
        version="0.1.0",
        packages=find_packages(),
        description="Save contacts from your terminal",
        url="https://github.com/wangonya/contacts-cli",
        author="Kelvin Wangonya",
        author_email="kwangonya@gmail.com",
        license="MIT",
        classifiers=[
            "License :: OSI Approved :: MIT License",
            "Programming Language :: Python :: 3",
            "Programming Language :: Python :: 3.7",
        ],
        install_requires=[
            "Click",
            "requests",
            ],
        entry_points="""
        [console_scripts]
        contacts=app:cli
        """,
        )