from typing import Optional
from math import fsum
from numpy import format_float_positional as ffp


class Calculator:
    def __init__(self, starting_value: float = 0, verbose: bool = False):
        """
        Initiates an instance of the Calculator class with the following variables:
        * result_in_memory - starting value of the calculator.
            Default set to 0.
        * operation_counter - number of operations made with the current
            run of the calculator. Default set to 0.
        * previous_value_in_memory - value of the result_in_memory before an
            operation. Default set to None.
        * verbose - boolean variable defining return type of operations from
            text to float values.
        """

        self.result_in_memory: float | int = starting_value
        self.operation_counter: int = 0
        self.__previous_value_in_memory: Optional[float] = None
        self.__verbose: bool = verbose

    @staticmethod
    def check_input_types(*args: float | int):
        """Asserts that all input values are numbers (floats or integers)."""
        assert all(
            [isinstance(argument, float | int) for argument in [*args]]
        ), "All inputs have to be of type Numeric."

    @staticmethod
    def find_decimal_point(*args: float | int) -> int:
        """
        Finds the largest number of decimal points for inputs to
        determine the number of decimal points in the return.

        Examples:
        self.find_decimal_point(0.4444, 0.222, 0, 5.55555)
        >>> 5
        self.find_decimal_point(-0.43, -0.2, 5000, 6.0001)
        >>> 4
        self.find_decimal_point(2, 1, 5000, 13444)
        >>> 0
        """

        if any([isinstance(argument, float) for argument in [*args]]):
            return max(
                [len(str(ffp(a)).split(".")[1]) for a in [*args] if not isinstance(a, int)]
            )
        else:
            return 0

    def store_memory(self):
        """Stores the previous value that was created by previous calculations."""
        self.__previous_value_in_memory = self.result_in_memory

    def count_operations(self, nr_of_operations: int = 1):
        self.operation_counter += nr_of_operations

    def change_return_type(self):
        """Changes the return type of instance methods to the opposite type."""
        self.__verbose = not self.__verbose

    def reset(self):
        """
        Resets the memory of operation results to 0 & the result of operations back to 0.
        """

        if self.__verbose:
            print(
                f"You've previously made {self.operation_counter} operations with the end result being {self.result_in_memory}."
            )
        self.result_in_memory = 0
        self.operation_counter = 0
        self.__previous_value_in_memory = None
        if self.__verbose:
            print("Your Calculator has been reset. Now the Current Memory is 0.")

    def add(self, *args: float | int) -> float | str:
        """
        Returns the sum of all provided arguments added to the value in memory.
        Decimal point is set to the maximum decimal point from all arguments passed into the method, 
        unless there are no non-zero integers after the point.

        Examples:
        Calculator(1).add(0.4444, 0.222, 0, 5.55555)
        >>> 7.22195
        Calculator(-100).add(-0.43, -0.2, 5000, 6.0001)
        >>> 4905.3701
        Calculator(-100, True).add(2, 1, 5000, 13444)
        >>> 'You have added 18447 to -100 to get: 18347.'
        """
        self.check_input_types(*args)
        self.store_memory()
        self.result_in_memory += fsum([*args])
        self.count_operations(len([*args]))
        decimal_point = self.find_decimal_point(*args)

        if self.__verbose:
            return f"""You have added {fsum([*args]):.{decimal_point}f} to {self.__previous_value_in_memory:.{decimal_point}f} to get: {self.result_in_memory:.{decimal_point}f}."""
        return (
            round(self.result_in_memory, decimal_point)
            if decimal_point
            else self.result_in_memory
        )

    def subtract(self, *args: float | int) -> float | str:
        """
        Returns the result of subtracting the sum of all provided arguments from the value in memory.
        Decimal point is set to the maximum decimal point from all arguments passed into the method.

        Examples:
        Calculator(1).subtract(0.4444, 0.222, 0, 5.55555)
        >>> -5.22195
        Calculator(-100).subtract(-0.43, -0.2, 5000, 6.0001)
        >>> -5105.3701
        Calculator(-100, True).subtract(2, 1, 5000, 13444)
        >>> 'You have subtracted 18447 from -100 to get: -18547.'
        """
        self.check_input_types(*args)
        self.store_memory()
        self.result_in_memory -= fsum([*args])
        self.count_operations(len([*args]))
        decimal_point = self.find_decimal_point(*args)
        if self.__verbose:
            return f"You have subtracted {fsum([*args]):.{decimal_point}f} from {self.__previous_value_in_memory:.{decimal_point}f} to get: {self.result_in_memory:.{decimal_point}f}."
        return (
            round(self.result_in_memory, decimal_point)
            if decimal_point
            else self.result_in_memory
        )

    def multiply(self, *args: float | int) -> float | str:
        """
        Returns the result of multiplying the value in memory with all provided arguments.
        Decimal point is set to the maximum decimal point from all arguments passed into the method, 
        unless there are no non-zero integers after the point.

        Examples:
        Calculator(1).multiply(0.4444, 0.222, 0, 5.55555)
        >>> 0.0
        Calculator(-100).multiply(-0.43, -0.2, 5000, 6.0001)
        >>> -258004.3
        Calculator(-100, True).multiply(2, 1, 5.001, 13)
        >>> 'You have timed 130.026 with -100.000 to get: -13002.600'
        """

        self.check_input_types(*args)
        self.store_memory()
        decimal_point = self.find_decimal_point(*args)

        for multiplier in [*args]:
            self.result_in_memory *= multiplier

        self.count_operations(len([*args]))
        if self.__verbose:
            return f"""You have timed {(self.result_in_memory / self.__previous_value_in_memory)
                                    if self.__previous_value_in_memory != 0
                                    and self.__previous_value_in_memory is not None
                                    else 0} with {self.__previous_value_in_memory:.{decimal_point}f} to get: {self.result_in_memory:.{decimal_point}f}"""
        return (
            round(self.result_in_memory, decimal_point)
            if decimal_point
            else self.result_in_memory
        )

    def divide(self, *args: float | int) -> float | str:
        """
        Returns the result of dividing the value in memory with
        all provided arguments. Decimal point is set to the maximum decimal point from all 
        arguments passed into the method, unless there are no non-zero integers after the point.

        Examples:
        Calculator(1).divide(0.4444, 0.222, 2, 5.55555)
        >>> 0.91225
        Calculator(-100).divide(-0.43, -0.2, 5000, 6.0001)
        >>> -0.0388
        Calculator(-100, True).divide(2, 1, 5.001)
        >>> 'You have divided -100.000 by 0.09998000399920015 to get: -9.998.'
        """

        self.check_input_types(*args)
        decimal_point = self.find_decimal_point(*args)
        assert all([*args]), """In order to be able to dive the resultin memory with a number,
                                that number must be non-zero."""

        self.store_memory()
        decimal_point = self.find_decimal_point(*args)

        for diviser in [*args]:
            self.result_in_memory /= diviser

        if self.__verbose:
            return f"""You have divided {self.__previous_value_in_memory:.{decimal_point}f} by {self.result_in_memory
                                                                            / self.__previous_value_in_memory
                                                                            if self.__previous_value_in_memory != 0
                                                                            and self.__previous_value_in_memory is not None
                                                                            else 0} to get: {self.result_in_memory:.{decimal_point}f}."""
        return (
            round(self.result_in_memory, decimal_point)
            if decimal_point
            else self.result_in_memory
        )
    
    def floor_divide(self, *args: float | int) -> float | str:
        """
        Returns the result of floor dividing the value in memory with
        all provided arguments. Decimal point is set to the maximum decimal point from all 
        arguments passed into the method, unless there are no non-zero integers after the point.

        Examples:
        Calculator(1).floor_divide(0.4444, 0.222, 0, 5.55555)
        >>> AssertionError: In order to be able to dive the resultin memory with a number,
                                that number must be non-zero.
        Calculator(5).floor_divide(1, 0.2325, 2, 6.2335)
        >>> 1.0
        Calculator(-100).floor_divide(-0.43, -0.2, 5000, 6.0001)
        >>> -1.0
        Calculator(-100, True).floor_divide(2, 4)
        >>> 'You have floor divided -100 by 0.13 to get: -13.'
        """

        self.check_input_types(*args)
        decimal_point = self.find_decimal_point(*args)
        assert all([*args]), """In order to be able to dive the resultin memory with a number,
                                that number must be non-zero."""

        self.store_memory()
        decimal_point = self.find_decimal_point(*args)

        for diviser in [*args]:
            self.result_in_memory //= diviser

        if self.__verbose:
            return f"""You have floor divided {self.__previous_value_in_memory:.{decimal_point}f} by {self.result_in_memory
                                                                            / self.__previous_value_in_memory
                                                                            if self.__previous_value_in_memory != 0
                                                                            and self.__previous_value_in_memory is not None
                                                                            else 0} to get: {self.result_in_memory:.{decimal_point}f}."""
        return (
            round(self.result_in_memory, decimal_point)
            if decimal_point
            else self.result_in_memory
        )

    def root(self, *args: float | int) -> float | str:
        """
        Returns the result of taking the nth root of the value in memory with
        all provided arguments for n. n is equivalent to root_number.
        Decimal point is set to the maximum decimal point from all arguments passed into the method, 
        unless there are no non-zero integers after the point.


        Examples:
        Calculator(1).root(0.4444, 0.222, 0, 5.55555)
        >>> AssertionError: In order to be able to take a root of a number, 
                        the root number has to be no zero.
        Calculator(5).root(1, 0.2325, 2, 6.2335)
        >>> 1.7424
        Calculator(-100).root(-0.43, -0.2, 5000, 6.0001)
        >>> AssertionError: In order to be able to take a root of a number, it must be non-negative.
        Calculator(1100, True).root(2, 4)
        >>> 'You have taken 2 consecutive roots of 1100 with the root numbers being 2, 4 to get: 2.'
        """

        self.check_input_types(*args)
        assert (self.result_in_memory > 0), "In order to be able to take a root of a number, it must be non-negative."
        assert all([*args]), "In order to be able to take a root of a number, the root number has to be no zero."

        self.store_memory()
        decimal_point = self.find_decimal_point(*args)

        for root in [*args]:
            self.result_in_memory **= 1 / root

        if self.__verbose:
            return f"""You have taken {len([*args]):.{decimal_point}f} consecutive roots of {self.__previous_value_in_memory
                                 if self.__previous_value_in_memory is not None
                                 else 0} with the root numbers being {", ".join(map(str, [*args]))} to get: {self.result_in_memory:.{decimal_point}f}."""
        return (
            round(self.result_in_memory, decimal_point)
            if decimal_point
            else self.result_in_memory
        )


if __name__ == "__main__":
    # Creating a Calculator instance with a starting value of 700
    calc = Calculator(700, True)

    # Testing check input types assertion test
    # calc.check_input_types(0.4444, 0.222, 0, "No")

    # Testing decimal point extraction
    calc.find_decimal_point(0.4444, 0.222, 0, 5.55555)

    # Testing out the .add instance method of the calculator:
    calc.add(4.28, 2.25, 2, 2.61, -9.84)

    # Testing out the .subtract instance method of the calculator:
    calc.subtract(4.28, 2.25, 2, 2.61, -9.84555)

    # Testing out the .subtract instance method of the calculator:
    calc.divide(25, 10, 5)

    # Getting the operation counter
    calc.operation_counter

    # Getting the value in memory
    calc.result_in_memory

    # Reseting the calculator:
    calc.reset()
