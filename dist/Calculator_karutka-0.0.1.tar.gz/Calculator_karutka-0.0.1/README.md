# Calculator Package

## Table of Contents
* Usage
* Methods within the package
* Dependencies
* How to install the package.
  
## Purpose

The purpose of this package is to provide capabilities of mathematical capabilities such as summing, subtracting, multiplying, dividing & taking multiple roots 
from float variables. The package provides ability for verbose action explanation for easier understanding of the operations made and remembers the result of the previous operations.

## Usage

In order to be able to use the package, you first need to install it through (Expanded on later). In order to us the calculator, you first need to instantiate an object from the imported Calculator class. 
The starting arguments of the package are as follows: 

Calculator(0: starting value which all further operations will be done on(default value = 0), False | True: verbose or simple return type - verbose explains what your operation did, whereas simple only returns the answer (default value = False)). 

All further operations are done through methods created within the Calculator class. 

# Methods within the package
* add(*args) - adds sum of all arguments to the value in memory.
* subtract(*args) - subtracts sum of all arguments from the value in memory.
* multiply(*args) - multiplies the value in memory with all arguments.
* divide(*args) - divides the value in memory by all arguments.
* floor_divide(*args) - performs floor division on the value in memory by all arguments.
* root(*args) - returns the result of subsequent root operations on the value in memory by all arguments.
* reset() - resets the value in memory & operation counter.
* change_return_type() - changes the way that the return is given by methods to a verbose/simple type.
  
## Dependencies
Here are the packages used within the package:
* from typing, module Optional.
* from math, module fsum.
* from numpy, module format_float_positional.

## How to install the package

You can install the package in multiple ways: 
1. First of them is to clone the repository and install it through pip from your local directory.

   pip install your/directory/to/the/downloaded/repository/file

2. Second is to install the package directly from the git repository:

  pip install git+https://github.com/repository_directory_on_git.git
